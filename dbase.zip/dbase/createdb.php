<?php

	// Create Database if not exist!

	require_once "../lib/env.php";
	$cnn = null;

	try {
		$cnn = new PDO("mysql:host={$host};", $uname, $pw);
		$cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		$sql = "CREATE DATABASE IF NOT EXISTS {$db}";
		$cnn->exec($sql);

		$sql = "use {$db}";
		$cnn->exec($sql);

		echo "Database: {$db}; Successfully Created!; <br>";
	} catch(PDOException $e) {
		echo "System Error ".$e->getMessage()."; <br>";
	}