<?php

	require_once "../lib/env.php";
	$cnn = null;

	try {
		$cnn = new PDO("mysql:host={$host};dbname={$db}", $uname, $pw);
		$cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		// Table name
		$tableName = 'employee_type_tbl';

		// Check if table exists
		$result = $cnn->prepare("SHOW TABLES LIKE '$tableName'");
		$count = $result->rowCount();

		if ($count == 0) {
			// Table does not exist, create it
			$createTableSQL = "CREATE TABLE $tableName (
				type_employee_no INT AUTO_INCREMENT PRIMARY KEY, 
				
				type_employee text NOT NULL, 
				type_employee_abrv text NOT NULL, 

				xdel int(1) NOT NULL, 
				createdby text NOT NULL, 
				modifiedby text NOT NULL, 
				modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
			)";
			$cnn->exec($createTableSQL);

			echo "Table '$tableName' created successfully. <br>";
		} else {
			echo "Table '$tableName' already exists. <br>";
		}
	} catch(PDOException $e) {
		echo "System Error ".$e->getMessage()."! <br>";
	}