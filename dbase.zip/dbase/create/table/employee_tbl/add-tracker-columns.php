<?php

	require_once "../../lib/env.php";
	$cnn = null;

	try {
		$cnn = new PDO("mysql:host={$host};dbname={$db}", $uname, $pw);
		$cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		$columns = [
			'employee_role'    => "INT(1) NOT NULL DEFAULT 0",
			'office_landmark'  => "TEXT",
			'office_longitude' => "DECIMAL(11,8) DEFAULT NULL",
			'office_latitude'  => "DECIMAL(10,8) DEFAULT NULL",
			'office_meter'     => "DECIMAL(10,2) DEFAULT NULL",
			'online_status'    => "INT(1) NOT NULL DEFAULT 0",
		];

		foreach ($columns as $col => $def) {
			$check = $cnn->prepare("SHOW COLUMNS FROM employee_tbl LIKE :col");
			$check->execute([':col' => $col]);
			if ($check->rowCount() == 0) {
				$cnn->exec("ALTER TABLE employee_tbl ADD COLUMN $col $def");
				echo "Column '$col' added successfully. <br>";
			} else {
				echo "Column '$col' already exists. <br>";
			}
		}

	} catch(PDOException $e) {
		echo "System Error: " . $e->getMessage() . "! <br>";
	}
