<?php

	require_once "../lib/env.php";
	$cnn = null;

	try {
		$cnn = new PDO("mysql:host={$host};dbname={$db}", $uname, $pw);
		$cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		// Table name
		$tableName = 'employee_tbl';

		// Check if table exists
		$result = $cnn->prepare("SHOW TABLES LIKE '$tableName'");
		$count = $result->rowCount();

		if ($count == 0) {
			// Table does not exist, create it
			$createTableSQL = "CREATE TABLE $tableName (
				emp_autoid INT AUTO_INCREMENT PRIMARY KEY, 

				agency_code text NOT NULL, 
				agency_name text NOT NULL, 

				nickname text NOT NULL, 
				emp_name_forid text NOT NULL, 
				officename_forid text NOT NULL, 
				designationforid text NOT NULL, 
				
				profileid text NOT NULL, 
				uid text NOT NULL, 
				emp_idcode text NOT NULL, 
				pinword text NOT NULL, 
				hr_emp_id text NOT NULL, 
				bio_loc_label text NOT NULL, 
				bio_location int(11) NOT NULL, 
				bio_no int(11) NOT NULL, 
				emp_name text NOT NULL, 
				gender text NOT NULL, 
				birthday date NOT NULL, 
				emp_age int(3) NOT NULL, 

				officeid int(11) NOT NULL, 
				officecode text NOT NULL, 
				officename text NOT NULL, 
				officetitle text NOT NULL, 
				officeabrv text NOT NULL, 
				oldofficeabrv text NOT NULL, 
				office_gps_location text NOT NULL, 
				headofficer text NOT NULL, 
				headtitle text NOT NULL, 
				auth_head text NOT NULL, 
				auth_title text NOT NULL, 
				auth_description text NOT NULL, 
				year_employed int(4) NOT NULL, 
				year_calc int(11) NOT NULL, 
				type_employee_no int(11) NOT NULL, 
				type_employee_abrv text NOT NULL, 
				type_employee text NOT NULL, 

				address text NOT NULL, 
				slingid int(1) NOT NULL, 
				pocketid int(1) NOT NULL, 
				for_id int(1) NOT NULL, 

				verified int(1) NOT NULL, 
				activated int(1) NOT NULL, 
				office_landmark text NOT NULL, 
				office_longitude text NOT NULL, 
				office_latitude text NOT NULL, 
				work_location int(1) NOT NULL, 
				
				shift_status int(1) NOT NULL, 
				time_editable int(1) NOT NULL, 
				priority_dtr int(1) NOT NULL, 
				time_editable_value int(1) NOT NULL, 

				allowed_ot int(1) NOT NULL, 

				plantilla_no text NOT NULL, 
				position text NOT NULL, 
				designation text NOT NULL, 
				position_class text NOT NULL, 

				salary_amount float NOT NULL, 
				salary_period text NOT NULL, 
				salary_amount_per_period float NOT NULL, 
				auth_annual_salary float NOT NULL, 
				actual_annual_salary float NOT NULL, 
				salary_grade int(3) NOT NULL, 
				salary_steps int(3) NOT NULL, 
				emp_area_code int(3) NOT NULL, 
				emp_area_type text NOT NULL, 
				emp_level text NOT NULL, 

				philhealth_contribution float NOT NULL, 
				pagibib_contribution float NOT NULL, 
				sss_contribution float NOT NULL, 
				gsis_contribution float NOT NULL, 
				employee_contribution float NOT NULL, 

				payroll_bank_name text NOT NULL, 
				payroll_bank_number text NOT NULL, 
				philhealth_no text NOT NULL, 
				pagibib_no text NOT NULL, 
				sss_no text NOT NULL, 
				gsis_no text NOT NULL, 
				tax_id text NOT NULL, 

				last_date_employment date NOT NULL, 
				date_issued date NOT NULL, 
				months_validity int(2) NOT NULL, 
				employment_status_no int(2) NOT NULL, 
				employment_status text NOT NULL, 
				employment_status_abvr text NOT NULL, 
				valid_until date NOT NULL, 

				mphone text NOT NULL, 
				empemail text NOT NULL, 
				designation_at text NOT NULL, 

				incaseofemergency_name text NOT NULL, 
				incaseofemergency_contact text NOT NULL, 
				incaseofemergency_relation text NOT NULL, 

				for_print_sling_id int(1) NOT NULL, 
				for_print_pocket_id int(1) NOT NULL, 

				printed_sling_id int(1) NOT NULL, 
				printed_pocket_id int(1) NOT NULL, 

				sling_id_paid int(1) NOT NULL, 
				pocket_id_paid int(1) NOT NULL, 

				sling_id_released int(1) NOT NULL, 
				pocket_id_released int(1) NOT NULL, 

				xdel int(1) NOT NULL, 
				createdby text NOT NULL, 
				modifiedby text NOT NULL, 
				modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
			)";
			$cnn->exec($createTableSQL);

			echo "Table '$tableName' created successfully. <br>";
		} else {
			echo "Table '$tableName' already exists. <br>";
		}
	} catch(PDOException $e) {
		echo "System Error ".$e->getMessage()." <br>";
	}

	// nickname varchar(8) NOT NULL, 
	// emp_name_forid varchar(28) NOT NULL, 
	// officename_forid varchar(75) NOT NULL, 
	// designationforid varchar(55) NOT NULL, 

	/**
	 * work_location = 0 | 1
	 * 		0 = Attendance Anywhere
	 * 		1 = On-Premises attendance
	 * 
	 * 
	 **/
