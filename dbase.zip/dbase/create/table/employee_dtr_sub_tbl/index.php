<?php

	require_once "../lib/env.php";
	$cnn = null;

	try {
		$cnn = new PDO("mysql:host={$host};dbname={$db}", $uname, $pw);
		$cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		// Table name
		$tableName = 'employee_dtr_sub_tbl';

		// Check if table exists
		$result = $cnn->prepare("SHOW TABLES LIKE '$tableName'");
		$count = $result->rowCount();

		if ($count == 0) {
			// Table does not exist, create it
			$createTableSQL = "CREATE TABLE $tableName (
				empdtr_sub_autoid INT AUTO_INCREMENT PRIMARY KEY, 

				agency_code text NOT NULL, 
				agency_name text NOT NULL, 

				emp_idcode text NOT NULL, 
				dtrcode text NOT NULL, 
				nameday varchar(3) NOT NULL, 
				dayno int(2) NOT NULL, 
				monthno int(2) NOT NULL, 
				monthname text NOT NULL, 
				yearno int(4) NOT NULL, 
				emp_name text NOT NULL, 
				bio_location text NOT NULL, 
				bio_no int(11) NOT NULL, 
				amtimein text NOT NULL, 
				amtimeout text NOT NULL, 
				pmtimein text NOT NULL, 
				pmtimeout text NOT NULL, 
				late_am int(11) NOT NULL, 
				late_pm int(11) NOT NULL, 
				utime_am int(11) NOT NULL, 
				utime_pm int(11) NOT NULL, 
				latemin int(11) NOT NULL, 
				utimemin int(11) NOT NULL, 
				tardymin int(11) NOT NULL, 
				lateutime_hour int(11) NOT NULL, 
				lateutime_min int(11) NOT NULL, 
				overtime_hour int(11) NOT NULL, 
				overtime_min int(11) NOT NULL, 

				attendance_gps_location_am_in text NOT NULL, 
				attendance_gps_location_am_out text NOT NULL, 
				attendance_gps_location_pm_in text NOT NULL, 
				attendance_gps_location_pm_out text NOT NULL, 

				allowed_ot int(1) NOT NULL, 

				xdel int(1) NOT NULL, 
				createdby text NOT NULL, 
				modifiedby text NOT NULL, 
				modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
			)";
			$cnn->exec($createTableSQL);

			echo "Table '$tableName' created successfully. <br>";
		} else {
			echo "Table '$tableName' already exists. <br>";
		}
	} catch(PDOException $e) {
		echo "System Error ".$e->getMessage()." <br>";
	}