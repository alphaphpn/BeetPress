<?php

	require_once "../lib/env.php";
	$cnn = null;

	try {
		$cnn = new PDO("mysql:host={$host};dbname={$db}", $uname, $pw);
		$cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		// Table name
		$tableName = 'employee_dtr_tbl';

		// Check if table exists
		$result = $cnn->prepare("SHOW TABLES LIKE '$tableName'");
		$count = $result->rowCount();

		if ($count == 0) {
			// Table does not exist, create it
			$createTableSQL = "CREATE TABLE $tableName (
				empdtr_autoid INT AUTO_INCREMENT PRIMARY KEY, 

				agency_code text NOT NULL, 
				agency_name text NOT NULL, 

				emp_idcode text NOT NULL, 
				dtrcode text NOT NULL, 
				yearno int(4) NOT NULL, 
				monthno int(2) NOT NULL, 
				monthname text NOT NULL, 
				profileid text NOT NULL, 
				bio_location text NOT NULL, 
				bio_no int(11) NOT NULL, 
				emp_name text NOT NULL, 
				officeid int(11) NOT NULL, 
				officecode text NOT NULL, 
				officename text NOT NULL, 
				officetitle text NOT NULL, 
				officeabrv text NOT NULL, 
				office_gps_location text NOT NULL, 
				type_employee_no int(11) NOT NULL, 
				type_employee_abrv text NOT NULL, 
				headofficer text NOT NULL, 
				headtitle text NOT NULL, 
				auth_head text NOT NULL, 
				auth_title text NOT NULL, 
				auth_description text NOT NULL, 
				utlate_hr int(11) NOT NULL, 
				utlate_min int(11) NOT NULL, 
				ot_hr int(11) NOT NULL, 
				ot_min int(11) NOT NULL, 

				shift_status int(1) NOT NULL, 
				time_editable int(1) NOT NULL, 
				priority_dtr int(1) NOT NULL, 
				time_editable_value int(1) NOT NULL, 

				allowed_ot int(1) NOT NULL, 

				xdel int(1) NOT NULL, 
				createdby text NOT NULL, 
				modifiedby text NOT NULL, 
				modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
			)";
			$cnn->exec($createTableSQL);

			echo "Table '$tableName' created successfully. <br>";
		} else {
			echo "Table '$tableName' already exists. <br>";
		}
	} catch(PDOException $e) {
		echo "System Error ".$e->getMessage()." <br>";
	}