<?php

	require_once "../lib/env.php";
	$cnn = null;

	try {
		$cnn = new PDO("mysql:host={$host};dbname={$db}", $uname, $pw);
		$cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		// Table name
		$tableName = 'profile_tbl';

		// Check if table exists
		$result = $cnn->prepare("SHOW TABLES LIKE '$tableName'");
		$count = $result->rowCount();

		if ($count == 0) {
			// Table does not exist, create it
			$createTableSQL = "CREATE TABLE $tableName (
				profile_autoid INT AUTO_INCREMENT PRIMARY KEY, 

				profileid text NOT NULL, 

				nickname varchar(8) NOT NULL, 

				ptitle text NOT NULL, 
				first_name text NOT NULL, 
				middle_name text NOT NULL, 
				last_name text NOT NULL, 
				suffix text NOT NULL, 
				gender text NOT NULL, 
				birth_date date NOT NULL, 
				birth_place text NOT NULL, 
				nationality text NOT NULL, 
				civil_status text NOT NULL, 
				bloodtype text NOT NULL, 

				email text NOT NULL, 
				photo text NOT NULL, 
				mobile text NOT NULL, 
				mobile2 text NOT NULL, 
				fbid text NOT NULL, 

				address text NOT NULL, 
				address_line_2 text NOT NULL, 

				street text NOT NULL, 
				barangay_code text NOT NULL, 
				barangay text NOT NULL, 

				municipality_code text NOT NULL, 
				municipality text NOT NULL, 
				zipcode int(11) NOT NULL, 

				district_no int(11) NOT NULL, 
				district_sign text NOT NULL, 

				province_code text NOT NULL, 
				province text NOT NULL, 

				region_code text NOT NULL, 
				region_no int(11) NOT NULL, 
				region_sign text NOT NULL, 
				region text NOT NULL, 

				country_id text NOT NULL, 
				country_code text NOT NULL, 
				country text NOT NULL, 
				postal text NOT NULL, 

				foreign_address text NOT NULL, 

				incaseofemergency_name text NOT NULL, 
				incaseofemergency_contact text NOT NULL, 
				incaseofemergency_relation text NOT NULL, 

				xdel int(1) NOT NULL, 
				createdby text NOT NULL, 
				modifiedby text NOT NULL, 
				modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
			)";
			$cnn->exec($createTableSQL);

			echo "Table '$tableName' created successfully. <br>";
		} else {
			echo "Table '$tableName' already exists. <br>";
		}
	} catch(PDOException $e) {
		echo "System Error ".$e->getMessage()." <br>";
	}