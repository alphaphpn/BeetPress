<?php

	require_once "../lib/env.php";
	require_once "../lib/function.php";
	$cnn = null;

	try {
		$cnn = new PDO("mysql:host={$host};dbname={$db}", $uname, $pw);
		$cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		// Table name
		$tableName = 'user_tbl';

		// Check if table exists
		$result = $cnn->prepare("SHOW TABLES LIKE '$tableName'");
		$count = $result->rowCount();

		if ($count == 0) {
			// Table does not exist, create it
			$createTableSQL = "CREATE TABLE $tableName (
				authid INT AUTO_INCREMENT PRIMARY KEY, 

				agency_code text NOT NULL, 
				agency_name text NOT NULL, 

				uid text NOT NULL, 
				profileid text NOT NULL, 
				uname text NOT NULL, 
				nickname text NOT NULL, 
				pword text NOT NULL, 
				country text NOT NULL, 
				countrycode int(11) NOT NULL, 
				zipcode int(11) NOT NULL, 
				phone text NOT NULL, 
				email text NOT NULL, 
				birthdate date NOT NULL, 
				verified int(1) NOT NULL, 
				ustat int(1) NOT NULL, 
				ulevel int(11) NOT NULL, 
				uposition text NOT NULL, 
				onoffline int(1) NOT NULL, 
				secure_question text NOT NULL, 
				secure_answer text NOT NULL, 
				officeid int(11) NOT NULL, 
				officeabrv text NOT NULL, 
				officecode text NOT NULL, 

				xdel int(1) NOT NULL, 
				createdby text NOT NULL, 
				modifiedby text NOT NULL, 
				modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
			)";
			$cnn->exec($createTableSQL);

			echo "Table '$tableName' created successfully. <br>";
		} else {
			echo "Table '$tableName' already exists. <br>";
		}
	} catch(PDOException $e) {
		echo "System Error ".$e->getMessage()." <br>";
	}

	// nickname varchar(8) NOT NULL, 