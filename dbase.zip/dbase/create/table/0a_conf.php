<?php

	require_once "../lib/env.php";
	$cnn = null;

	try {
		$cnn = new PDO("mysql:host={$host};dbname={$db}", $uname, $pw);
		$cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		// Table name
		$tableName = '0a_conf';

		// Check if table exists
		$result = $cnn->prepare("SHOW TABLES LIKE '$tableName'");
		$count = $result->rowCount();

		if ($count == 0) {
			// Table does not exist, create it
			$createTableSQL = "CREATE TABLE $tableName (
				agency_id INT AUTO_INCREMENT PRIMARY KEY, 
				agency_code text NOT NULL, 
				agency_name text NOT NULL, 
				sys_name text NOT NULL, 
				sys_version text NOT NULL, 
				sys_logo text NOT NULL, 
				navbar_logo text NOT NULL, 
				navbar_logo_scroll text NOT NULL, 
				favicon text NOT NULL, 
				owner_name text NOT NULL, 
				on_offline INT(1) NOT NULL, 
				account_enabled INT(1) NOT NULL, 
				status text NOT NULL, 
				modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
			)";
			$cnn->exec($createTableSQL);

			echo "Table '$tableName' created successfully. <br>";
		} else {
			echo "Table '$tableName' already exists. <br>";
		}
	} catch(PDOException $e) {
		echo "System Error ".$e->getMessage()."! <br>";
	}

	

	