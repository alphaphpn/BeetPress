<?php

	require_once "../lib/env.php";
	$cnn = null;

	try {
		$cnn = new PDO("mysql:host={$host};dbname={$db}", $uname, $pw);
		$cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		// Table name
		$tableName = 'employee_work_history_tbl';

		// Check if table exists
		$result = $cnn->prepare("SHOW TABLES LIKE '$tableName'");
		$count = $result->rowCount();

		if ($count == 0) {
			// Table does not exist, create it
			$createTableSQL = "CREATE TABLE $tableName (
				empwkhsty_autoid INT AUTO_INCREMENT PRIMARY KEY, 

				agency_code text NOT NULL, 
				agency_name text NOT NULL, 
				
				profileid text NOT NULL, 
				emp_idcode text NOT NULL, 
				hr_emp_id text NOT NULL, 
				bio_location text NOT NULL, 
				bio_no int(11) NOT NULL, 
				emp_name text NOT NULL, 
				gender text NOT NULL, 
				birthday date NOT NULL, 
				emp_age int(3) NOT NULL, 

				officeid int(11) NOT NULL, 
				officecode text NOT NULL, 
				officename text NOT NULL, 
				officetitle text NOT NULL, 
				officeabrv text NOT NULL, 
				headofficer text NOT NULL, 
				headtitle text NOT NULL, 
				auth_head text NOT NULL, 
				auth_title text NOT NULL, 
				auth_description text NOT NULL, 
				year_employed int(4) NOT NULL, 
				year_calc int(11) NOT NULL, 
				type_employee_no int(11) NOT NULL, 
				type_employee_abrv text NOT NULL, 
				type_employee text NOT NULL, 

				plantilla_no text NOT NULL, 
				position text NOT NULL, 
				designation text NOT NULL, 
				position_class text NOT NULL, 

				salary_amount float NOT NULL, 
				salary_period text NOT NULL, 
				salary_amount_per_period float NOT NULL, 
				auth_annual_salary float NOT NULL, 
				actual_annual_salary float NOT NULL, 
				salary_grade int(3) NOT NULL, 
				salary_steps int(3) NOT NULL, 
				emp_area_code int(3) NOT NULL, 
				emp_area_type text NOT NULL, 
				emp_level text NOT NULL, 

				payroll_bank_name text NOT NULL, 
				payroll_bank_number text NOT NULL, 
				philhealth_no text NOT NULL, 
				pagibib_no text NOT NULL, 
				sss_no text NOT NULL, 
				gsis_no text NOT NULL, 
				tax_id text NOT NULL, 

				philhealth_contribution float NOT NULL, 
				pagibib_contribution float NOT NULL, 
				sss_contribution float NOT NULL, 
				gsis_contribution float NOT NULL, 
				employee_contribution float NOT NULL, 

				valid_on date NOT NULL, 
				months_validity int(2) NOT NULL, 
				employment_status_no int(2) NOT NULL, 
				employment_status text NOT NULL, 
				valid_until date NOT NULL, 

				xdel int(1) NOT NULL, 
				createdby text NOT NULL, 
				modifiedby text NOT NULL, 
				modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
			)";
			$cnn->exec($createTableSQL);

			echo "Table '$tableName' created successfully. <br>";
		} else {
			echo "Table '$tableName' already exists. <br>";
		}
	} catch(PDOException $e) {
		echo "System Error ".$e->getMessage()." <br>";
	}