<?php

	require_once "../lib/env.php";
	$cnn = null;

	try {
		$cnn = new PDO("mysql:host={$host};dbname={$db}", $uname, $pw);
		$cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		// Table name
		$tableName = 'accounting_code_tbl';

		// Check if table exists
		$result = $cnn->prepare("SHOW TABLES LIKE '$tableName'");
		$count = $result->rowCount();

		if ($count == 0) {
			// Table does not exist, create it
			$createTableSQL = "CREATE TABLE $tableName (
				accounting_code_autoid INT AUTO_INCREMENT PRIMARY KEY, 

				agency_code text NOT NULL, 
				agency_name text NOT NULL, 

				account_code text NOT NULL, 
				account_title text NOT NULL, 
				normal_balance text NOT NULL, 
				description text NOT NULL, 

				account_group_no varchar(1) NOT NULL, 
				account_group_title text NOT NULL, 

				major_account_group_no varchar(2) NOT NULL, 
				major_account_group_title text NOT NULL, 

				sub_major_account_group_no varchar(2) NOT NULL, 
				sub_major_account_group_title text NOT NULL, 

				general_ledger_account_no varchar(2) NOT NULL, 
				general_ledger_account_title text NOT NULL, 

				general_ledger_contra_account_no varchar(1) NOT NULL, 
				general_ledger_contra_account_title text NOT NULL, 

				uacs_sub_object_code_no varchar(2) NOT NULL, 
				uacs_sub_object_code_title text NOT NULL, 

				xdel int(1) NOT NULL, 
				createdby text NOT NULL, 
				modifiedby text NOT NULL, 
				modified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, 
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
			)";
			$cnn->exec($createTableSQL);

			echo "Table '$tableName' created successfully. <br>";
		} else {
			echo "Table '$tableName' already exists. <br>";
		}
	} catch(PDOException $e) {
		echo "System Error ".$e->getMessage()." <br>";
	}