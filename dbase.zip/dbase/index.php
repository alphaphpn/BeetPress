<?php

	include_once "../lib/env.php"; 
	include_once "../app/theme/{$theme}/template-part/header.php"; 
	include_once "../app/theme/{$theme}/template-part/navbar.php"; 

?>

	<div class="position-relative w-100 h-100 vh-93 clearfix">
		<div class="container">
			<div class="w-100 vh-86 m-auto row">
				<div class="col d-flex justify-content-center m-auto">
					<div class="bg-light p-5 border border-5 border-warning">

						<?php 

							try {
								$cnn = null;

								$cnn = new PDO("mysql:host={$host};dbname={$db}", $uname, $pw);
								$cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

								// Check if user_tbl table exists
								$resultUserTbl1 = $cnn->prepare("SELECT * FROM user_tbl");
								$resultUserTbl1->execute();
								$countUserTbl1 = $resultUserTbl1->rowCount();
								if ($countUserTbl1 > 0) {
									echo "Database Already Exist!. <br>";
								} else {
									require_once "createdb.php"; // Main Database Created
									require_once "create/table/0a_conf.php"; // Configuration Table Created

									// Table Created
									require_once "create/table/user_tbl/index.php"; 
									require_once "create/table/profile_tbl/index.php"; 
									require_once "create/table/profile_ids_tbl/index.php"; 
									require_once "create/table/profile_eligibility_tbl/index.php"; 

									require_once "create/table/accounting_code_tbl/index.php"; 
									require_once "create/table/holidays_tbl/index.php"; 
									require_once "create/table/halfday_tbl/index.php"; 
									require_once "create/table/office_tbl/index.php"; 
									require_once "create/table/office_signatory_tbl/index.php"; 

									require_once "create/table/employee_type_tbl/index.php"; 
									require_once "create/table/employee_tbl/index.php"; 
									require_once "create/table/employee_dtr_tbl/index.php"; 
									require_once "create/table/employee_dtr_sub_tbl/index.php"; 
									require_once "create/table/employee_att_log_tbl/index.php"; 
									require_once "create/table/employee_work_history_tbl/index.php"; 
									require_once "create/table/employee_device_tbl/index.php"; 

									require_once "create/table/plantilla_tbl/index.php"; 
									require_once "create/table/plantilla_sub_tbl/index.php"; 
									require_once "create/table/plantilla_personnel_tbl/index.php"; 

									require_once "create/table/bio_location_tbl/index.php";

									require_once "create/table/id_type_person_tbl/index.php";

									// insert default data
									require_once "default_data.php";
								}
							} catch ( PDOException $e ) {
								echo "System Error ".$e->getMessage()." <br><br>";

								require_once "createdb.php"; // Main Database Created
								require_once "create/table/0a_conf.php"; // Configuration Table Created

								// Table Created
								require_once "create/table/user_tbl/index.php"; 
								require_once "create/table/profile_tbl/index.php"; 
								require_once "create/table/profile_ids_tbl/index.php"; 
								require_once "create/table/profile_eligibility_tbl/index.php"; 

								require_once "create/table/accounting_code_tbl/index.php"; 
								require_once "create/table/holidays_tbl/index.php"; 
								require_once "create/table/halfday_tbl/index.php"; 
								require_once "create/table/office_tbl/index.php"; 
								require_once "create/table/office_signatory_tbl/index.php"; 

								require_once "create/table/employee_type_tbl/index.php"; 
								require_once "create/table/employee_tbl/index.php"; 
								require_once "create/table/employee_dtr_tbl/index.php"; 
								require_once "create/table/employee_dtr_sub_tbl/index.php"; 
								require_once "create/table/employee_att_log_tbl/index.php"; 
								require_once "create/table/employee_work_history_tbl/index.php"; 
								require_once "create/table/employee_device_tbl/index.php"; 

								require_once "create/table/plantilla_tbl/index.php"; 
								require_once "create/table/plantilla_sub_tbl/index.php"; 
								require_once "create/table/plantilla_personnel_tbl/index.php"; 

								require_once "create/table/bio_location_tbl/index.php";

								require_once "create/table/id_type_person_tbl/index.php";

								// insert default data
								require_once "default_data.php";
							}
							
						?>

					</div>
				</div>
			</div>
		</div>
	</div>

<?php include_once "../app/theme/{$theme}/template-part/footer.php"; ?>