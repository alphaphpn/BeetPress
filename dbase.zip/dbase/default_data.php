<?php

	try {

		require_once "../lib/env.php";

		$cnn = null;

		$cnn = new PDO("mysql:host={$host};dbname={$db}", $uname, $pw);
		$cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

		require_once "../lib/function.php";

		$the_agency_code = trim("PLGU-ZSP");
		$the_agency_name = "Provincial Government of Zamboanga Sibugay";

		$the_country = trim("Philippines");
		$the_country_code = 63;
		$the_country_id = trim("C1063");

		$the_ulevel = 12;
		$the_uposition = trim("User");

		$the_ulevel_empl = 14;
		$the_uposition_empl = trim("Employee");
		
		$the_province = trim("Zamboanga Sibugay");
		$the_province_code = trim("C1063030906");
		$the_region = trim("Zamboanga Peninsula");
		$the_region_code = trim("C10630309");
		$the_region_no = 9;
		$the_region_sign = trim("IX");

		$the_nationality = trim("Filipino");

		$createdby = trim("sadmin");
		$modifiedby = trim("sadmin");

		$uidx1 = trim(randomCodexz());
		$uidx2 = trim(randomCodexz());
		$uidx3 = trim(randomCodexz());
		$uidx4 = trim(randomCodexz());
		$uidx5 = trim(randomCodexz());
		$uidx6 = trim(randomCodexz());
		$uidx7 = trim(randomCodexz());
		$uidx8 = trim(randomCodexz());
		$uidx9 = trim(randomCodexz());
		$uidx10 = trim(randomCodexz());
		$uidx11 = trim(randomCodexz());
		$uidx12 = trim(randomCodexz());
		$uidx13 = trim(randomCodexz());
		$uidx14 = trim(randomCodexz());

		// Check if user_tbl table exists
		$sampleuname = trim('employee');
		$resultUserTbl = $cnn->prepare("SELECT * FROM user_tbl WHERE uname=:uname");
		$resultUserTbl->bindParam(':uname', $sampleuname);
		$resultUserTbl->execute();
		$countUserTbl = $resultUserTbl->rowCount();
		if ($countUserTbl > 0) {
			echo "Already had user_tbl Default Data!. <br>";
		} else {
			// insert default data.
			$insertDefaultData = "INSERT INTO user_tbl 
				(uid,profileid,uname,pword,phone,country,countrycode,zipcode,email,verified,ustat,ulevel,uposition,createdby,modifiedby,agency_code,agency_name,nickname) VALUES 
				(:uidx1,:uidx1,trim('sadmin'),trim(md5('!Aupwrx#3908^')),'9000000000',trim('Philippines'),'63','7001',trim('alphaphpn@gmail.com'),'1','1','1',trim('Built-in Administrator'),trim('sadmin'),trim('sadmin'),'','','sadmin'), 
				(:uidx2,:uidx2,trim('admin'),trim(md5('/Kwyqrs*6495<')),'9000000000',trim('Philippines'),'63','7001',trim('alphaphpn@gmail.com'),'1','1','2',trim('Administrator'),trim('sadmin'),trim('sadmin'),'','','admin'), 
				(:uidx3,:uidx3,trim('owner'),trim(md5('#Dnwiry>7029!')),'9000000000',trim('Philippines'),'63','7001',trim('alphaphpn@gmail.com'),'1','1','3',trim('Owner'),trim('sadmin'),trim('sadmin'),'','','owner'), 
				(:uidx4,:uidx4,trim('manager'),trim(md5('>Jvtleb*2569>')),'9000000000',trim('Philippines'),'63','7001',trim('alphaphpn@gmail.com'),'1','1','4',trim('Manager'),trim('sadmin'),trim('sadmin'),'','','manager'), 
				(:uidx5,:uidx5,trim('secretary'),trim(md5('~Vyamfq#9856*')),'9000000000',trim('Philippines'),'63','7001',trim('alphaphpn@gmail.com'),'1','1','5',trim('Secretary'),trim('sadmin'),trim('sadmin'),'','','secretary'), 
				(:uidx6,:uidx6,trim('staff'),trim(md5('@Bpyguj!8516>')),'9000000000',trim('Philippines'),'63','7001',trim('alphaphpn@gmail.com'),'1','1','6',trim('Staff'),trim('sadmin'),trim('sadmin'),'','','staff'), 
				(:uidx7,:uidx7,trim('editor'),trim(md5('>Twsieb^3904~')),'9000000000',trim('Philippines'),'63','7001',trim('alphaphpn@gmail.com'),'1','1','7',trim('Editor'),trim('sadmin'),trim('sadmin'),'','','editor'), 
				(:uidx8,:uidx8,trim('author'),trim(md5('#Rohsgp#3546/')),'9000000000',trim('Philippines'),'63','7001',trim('alphaphpn@gmail.com'),'1','1','8',trim('Author'),trim('sadmin'),trim('sadmin'),'','','author'), 
				(:uidx9,:uidx9,trim('contributor'),trim(md5('*Xmrpbi!5326<')),'9000000000',trim('Philippines'),'63','7001',trim('alphaphpn@gmail.com'),'1','1','9',trim('Contributor'),trim('sadmin'),trim('sadmin'),'','','contributor'), 
				(:uidx10,:uidx10,trim('subscriber'),trim(md5('#Izsivp>5074@')),'9000000000',trim('Philippines'),'63','7001',trim('alphaphpn@gmail.com'),'1','1','10',trim('Subscriber'),trim('sadmin'),trim('sadmin'),'','','subscriber'), 
				(:uidx11,:uidx11,trim('customer'),trim(md5('/Kmvacl*3068~')),'9000000000',trim('Philippines'),'63','7001',trim('alphaphpn@gmail.com'),'1','1','11',trim('Customer'),trim('sadmin'),trim('sadmin'),'','','customer'), 
				(:uidx12,:uidx12,trim('user'),trim(md5('~Eyflzq~8091>')),'9000000000',trim('Philippines'),'63','7001',trim('alphaphpn@gmail.com'),'1','1','12',trim('User'),trim('sadmin'),trim('sadmin'),'','','user'), 
				(:uidx13,:uidx13,trim('guest'),trim(md5('!Lefpir*3129^')),'9000000000',trim('Philippines'),'63','7001',trim('alphaphpn@gmail.com'),'1','1','13',trim('Guest'),trim('sadmin'),trim('sadmin'),'','','guest'), 
				(:uidx14,:uidx14,trim('employee'),trim(md5('*Nxrnvm#2341@')),'9000000000',trim('Philippines'),'63','7001',trim('alphaphpn@gmail.com'),'1','1','14',trim('Employee'),trim('sadmin'),trim('sadmin'),:theagencycode,:theagencyname,'employee')
			";

			// 1 Built-in Administrator [sadmin]
			// 2 Administrator [admin]
			// 14 Employee [employee]

			// 15 Human Resource Manager
			// 16 Head Officer
			// 17 Assistant Officer

			$stmtDefaultData = $cnn->prepare($insertDefaultData);
			$stmtDefaultData->bindParam(':uidx1', $uidx1);
			$stmtDefaultData->bindParam(':uidx2', $uidx2);
			$stmtDefaultData->bindParam(':uidx3', $uidx3);
			$stmtDefaultData->bindParam(':uidx4', $uidx4);
			$stmtDefaultData->bindParam(':uidx5', $uidx5);
			$stmtDefaultData->bindParam(':uidx6', $uidx6);
			$stmtDefaultData->bindParam(':uidx7', $uidx7);
			$stmtDefaultData->bindParam(':uidx8', $uidx8);
			$stmtDefaultData->bindParam(':uidx9', $uidx9);
			$stmtDefaultData->bindParam(':uidx10', $uidx10);
			$stmtDefaultData->bindParam(':uidx11', $uidx11);
			$stmtDefaultData->bindParam(':uidx12', $uidx12);
			$stmtDefaultData->bindParam(':uidx13', $uidx13);
			$stmtDefaultData->bindParam(':uidx14', $uidx14);

			$stmtDefaultData->bindParam(':theagencycode', $the_agency_code);
			$stmtDefaultData->bindParam(':theagencyname', $the_agency_name);

			$stmtDefaultData->execute();

			echo "Default data added @ user_tbl successfully inserted. <br>";
		}

		// Check if profile_tbl table exists
		$resultProfileTbl = $cnn->prepare("SELECT * FROM profile_tbl");
		$resultProfileTbl->execute();
		$countProfileTbl = $resultProfileTbl->rowCount();
		if ($countProfileTbl == 0) {
			// insert default data.
			$insertProfileTbl = "INSERT INTO profile_tbl 
				(profileid,first_name,middle_name,last_name,gender,birth_date,email,mobile,country_code,createdby,modifiedby,nickname) VALUES 
				(:uidx1,trim('Super Admin'),trim('Middlename'),trim('Surname'),trim('Male'),trim('1985-05-20'),trim('alphaphpn@gmail.com'),trim('9000000000'),trim('63'),trim('sadmin'),trim('sadmin'),trim('sadmin')), 
				(:uidx2,trim('Administrator'),trim('Middlename'),trim('Surname'),trim('Male'),trim('1985-05-20'),trim('alphaphpn@gmail.com'),trim('9000000000'),trim('63'),trim('sadmin'),trim('sadmin'),trim('admin')), 
				(:uidx3,trim('Owner'),trim('Middlename'),trim('Surname'),trim('Male'),trim('1985-05-20'),trim('alphaphpn@gmail.com'),trim('9000000000'),trim('63'),trim('sadmin'),trim('sadmin'),trim('owner')), 
				(:uidx4,trim('Manager'),trim('Middlename'),trim('Surname'),trim('Male'),trim('1985-05-20'),trim('alphaphpn@gmail.com'),trim('9000000000'),trim('63'),trim('sadmin'),trim('sadmin'),trim('manager')), 
				(:uidx5,trim('Secretary'),trim('Middlename'),trim('Surname'),trim('Male'),trim('1985-05-20'),trim('alphaphpn@gmail.com'),trim('9000000000'),trim('63'),trim('sadmin'),trim('sadmin'),trim('secretary')), 
				(:uidx6,trim('Staff'),trim('Middlename'),trim('Surname'),trim('Male'),trim('1985-05-20'),trim('alphaphpn@gmail.com'),trim('9000000000'),trim('63'),trim('sadmin'),trim('sadmin'),trim('staff')), 
				(:uidx7,trim('Editor'),trim('Middlename'),trim('Surname'),trim('Male'),trim('1985-05-20'),trim('alphaphpn@gmail.com'),trim('9000000000'),trim('63'),trim('sadmin'),trim('sadmin'),trim('editor')), 
				(:uidx8,trim('Author'),trim('Middlename'),trim('Surname'),trim('Male'),trim('1985-05-20'),trim('alphaphpn@gmail.com'),trim('9000000000'),trim('63'),trim('sadmin'),trim('sadmin'),trim('author')), 
				(:uidx9,trim('Contributor'),trim('Middlename'),trim('Surname'),trim('Male'),trim('1985-05-20'),trim('alphaphpn@gmail.com'),trim('9000000000'),trim('63'),trim('sadmin'),trim('sadmin'),trim('contributor')), 
				(:uidx10,trim('Subscriber'),trim('Middlename'),trim('Surname'),trim('Male'),trim('1985-05-20'),trim('alphaphpn@gmail.com'),trim('9000000000'),trim('63'),trim('sadmin'),trim('sadmin'),trim('subscriber')), 
				(:uidx11,trim('Customer'),trim('Middlename'),trim('Surname'),trim('Male'),trim('1985-05-20'),trim('alphaphpn@gmail.com'),trim('9000000000'),trim('63'),trim('sadmin'),trim('sadmin'),trim('customer')), 
				(:uidx12,trim('User'),trim('Middlename'),trim('Surname'),trim('Male'),trim('1985-05-20'),trim('alphaphpn@gmail.com'),trim('9000000000'),trim('63'),trim('sadmin'),trim('sadmin'),trim('user')), 
				(:uidx13,trim('Guest'),trim('Middlename'),trim('Surname'),trim('Male'),trim('1985-05-20'),trim('alphaphpn@gmail.com'),trim('9000000000'),trim('63'),trim('sadmin'),trim('sadmin'),trim('guest')), 
				(:uidx14,trim('Employee'),trim('Middlename'),trim('Surname'),trim('Male'),trim('1985-05-20'),trim('alphaphpn@gmail.com'),trim('9000000000'),trim('63'),trim('sadmin'),trim('sadmin'),trim('employee'))
			";
			$stmtProfileTbl = $cnn->prepare($insertProfileTbl);
			$stmtProfileTbl->bindParam(':uidx1', $uidx1);
			$stmtProfileTbl->bindParam(':uidx2', $uidx2);
			$stmtProfileTbl->bindParam(':uidx3', $uidx3);
			$stmtProfileTbl->bindParam(':uidx4', $uidx4);
			$stmtProfileTbl->bindParam(':uidx5', $uidx5);
			$stmtProfileTbl->bindParam(':uidx6', $uidx6);
			$stmtProfileTbl->bindParam(':uidx7', $uidx7);
			$stmtProfileTbl->bindParam(':uidx8', $uidx8);
			$stmtProfileTbl->bindParam(':uidx9', $uidx9);
			$stmtProfileTbl->bindParam(':uidx10', $uidx10);
			$stmtProfileTbl->bindParam(':uidx11', $uidx11);
			$stmtProfileTbl->bindParam(':uidx12', $uidx12);
			$stmtProfileTbl->bindParam(':uidx13', $uidx13);
			$stmtProfileTbl->bindParam(':uidx14', $uidx14);
			$stmtProfileTbl->execute();

			echo "Default data added @ profile_tbl successfully inserted. <br>";
		} else {
			echo "Already had profile_tbl Default Data! <br>";
		}

		// Check if employee_tbl table exists
		$resultEmployeeTbl = $cnn->prepare("SELECT * FROM employee_tbl");
		$resultEmployeeTbl->execute();
		$countEmployeeTbl = $resultEmployeeTbl->rowCount();
		if ($countEmployeeTbl == 0) {
			// insert default data.
			$pinwordg = md5(trim("198520"));
			$insertEmployeeTbl = "INSERT INTO employee_tbl 
				(profileid,uid,emp_idcode,pinword,hr_emp_id,bio_no,emp_name,activated,shift_status,time_editable,priority_dtr,createdby,modifiedby,office_gps_location,time_editable_value,agency_code,agency_name,officeid,officecode,officename,officetitle,officeabrv,oldofficeabrv,type_employee_no,type_employee,type_employee_abrv,headofficer,headtitle,auth_head,auth_title,auth_description,mphone,empemail,designation_at,nickname,emp_name_forid,officename_forid,designationforid) VALUES (:uidx14,:uidx14,'10000000',:pinwordg,'10000000','10000000','Employee','1','1','1','1','sadmin','sadmin','7.7881218435487245,122.57361312438182','3',:theagencycode,:theagencyname,'921011','1011','Governor','Office of the Provincial Governor','OPG','PGO','1',trim('Regular/Permanent'),trim('REG'),'Ann K. Hofer','Governor','Atty. Christian Jay M. Millena','Provincial Administrator','By authority of the Governor','+639000000000','employee@sibugay.gov.ph','ICT Office',trim('employee'),trim('Employee E. Lastname'),trim('Office of the Provincial Information and Communications Technology'),'Computer Operator')";
			$stmtEmployeeTbl = $cnn->prepare($insertEmployeeTbl);
			$stmtEmployeeTbl->bindParam(':uidx14', $uidx14);
			$stmtEmployeeTbl->bindParam(':pinwordg', $pinwordg);

			$stmtEmployeeTbl->bindParam(':theagencycode', $the_agency_code);
			$stmtEmployeeTbl->bindParam(':theagencyname', $the_agency_name);

			$stmtEmployeeTbl->execute();

			echo "Default data added @ employee_tbl successfully inserted. <br>";
		} else {
			echo "Already had employee_tbl Default Data! <br>";
		}

		// Check if office_tbl table exists
		$resultOfficeTbl = $cnn->prepare("SELECT * FROM office_tbl");
		$resultOfficeTbl->execute();
		$countOfficeTbl = $resultOfficeTbl->rowCount();
		if ($countOfficeTbl == 0) {
			// insert default data.
			$insertOfficeTbl = "INSERT INTO office_tbl 
				(agency_code,agency_name,officeid,officecode,officename,officetitle,officeabrv,oldofficeabrv) VALUES 
				(:theagencycode,:theagencyname,'921011','1011','Governor','Office of the Provincial Governor','OPG','PGO'), 
				(:theagencycode,:theagencyname,'92101102','1011','Nutrition','Office of the Provincial Nutrition','OPN',''), 
				(:theagencycode,:theagencyname,'92101103','1011','Security','Office of the Provincial Security Guard','OPSG','PSG'), 
				(:theagencycode,:theagencyname,'92101104','1011','MSU','MSU Buug School of Nursing Ipil Extension','MSU',''), 
				(:theagencycode,:theagencyname,'92101105','1011','SPTC','Sibugay Provincial Training Center','SPTC',''), 
				(:theagencycode,:theagencyname,'92101106','1011','ICT','Office of the Provincial Information and Communication Technology','OPICT',''), 
				(:theagencycode,:theagencyname,'921016','1016','Vice Governor','Office of the Provincial Vice Governor','OPVG','PVGO'), 
				(:theagencycode,:theagencyname,'921021','1021','Sangguniang Panlalawigan','Office of the Provincial Sangguniang Panlalawigan','OPSP','SP'), 
				(:theagencycode,:theagencyname,'921022','1022','Secretary','Office of the Secretary to the Sangguniang Panlalawigan','OPSec',''), 
				(:theagencycode,:theagencyname,'921031','1031','Administrator','Office of the Provincial Administrator','OPAd',''), 
				(:theagencycode,:theagencyname,'921032','1032','Human Resource Management','Office of the Provincial Human Resource Management','OPHRM','PHRMO'), 
				(:theagencycode,:theagencyname,'921041','1041','Planning and Development','Office of the Provincial Planning and Development Coordinator','OPPDC','PPDO'), 
				(:theagencycode,:theagencyname,'921061','1061','General Services','Office of the Provincial General Services','OPGS','PGSO'), 
				(:theagencycode,:theagencyname,'921071','1071','Budget','Office of the Provincial Budget','OPB','PBO'), 
				(:theagencycode,:theagencyname,'92107101','1071','Procurement Service Depot','Office of the Provincial Procurement Service Depot','OPPSD','PS-DBM'), 
				(:theagencycode,:theagencyname,'921081','1081','Accounting','Office of the Provincial Accountant','OPAcc','PAccO'), 
				(:theagencycode,:theagencyname,'921091','1091','Treasurer','Office of the Provincial Treasurer','OPT','PTO'), 
				(:theagencycode,:theagencyname,'921101','1101','Assessor','Office of the Provincial Assessor','OPAss','PAssO'), 
				(:theagencycode,:theagencyname,'921131','1131','Legal','Office of the Provincial Legal','OPL','PLO'), 
				(:theagencycode,:theagencyname,'924411','4411','Health','Office of the Provincial Health','OPH','IPHO'), 
				(:theagencycode,:theagencyname,'927611','7611','Social Welfare and Development','Office of the Provincial Social Welfare and Development','OPSWD','PSWDO'), 
				(:theagencycode,:theagencyname,'928711','8711','Agriculture','Office of the Provincial Agriculture','OPAg',''), 
				(:theagencycode,:theagencyname,'928721','8721','Veterinary','Office of the Provincial Veterinary','OPVet','Pvet'), 
				(:theagencycode,:theagencyname,'928731','8731','Environment and Natural Resources','Office of the Provincial Environment and Natural Resource','OPENR','PENRO'), 
				(:theagencycode,:theagencyname,'928751','8751','Engineering','Office of the Provincial Engineering','OPE','PEO'), 
				(:theagencycode,:theagencyname,'928761','8761','Cooperative','Office of the Provincial Cooperative','OPC','PCO'), 
				(:theagencycode,:theagencyname,'929940','9940','Disaster Risk Reduction','Office of the Provincial Disaster Risk Reduction Management','OPDRRM','PDRRMO'), 
				(:theagencycode,:theagencyname,'921061969','1061-969','Bids and Awards Committee','Office of the Provincial Bids and Awards Committee','OPBAC','BAC'), 
				(:theagencycode,:theagencyname,'92111101','1111-01','Internal Audit Service','Office of the Provincial Internal Audit Service','OPIAS','IAS'), 
				(:theagencycode,:theagencyname,'92441101','4411-01','Medical Center','Dr. George Tocao Hofer Medical Center','DGTHMC','ZSPH')
			";
			$stmtOfficeTbl = $cnn->prepare($insertOfficeTbl);

			$stmtOfficeTbl->bindParam(':theagencycode', $the_agency_code);
			$stmtOfficeTbl->bindParam(':theagencyname', $the_agency_name);

			$stmtOfficeTbl->execute();

			echo "Default data added @ office_tbl successfully inserted. <br>";
		} else {
			echo "Already had office_tbl Default Data! <br>";
		}

		// Check if office_signatory_tbl table exists
		$resultOfficeSignatoryTbl = $cnn->prepare("SELECT * FROM office_signatory_tbl");
		$resultOfficeSignatoryTbl->execute();
		$countOfficeSignatoryTbl = $resultOfficeSignatoryTbl->rowCount();
		if ($countOfficeSignatoryTbl == 0) {
			// insert default data.
			$insertOfficeSignatoryTbl = "INSERT INTO office_signatory_tbl 
				(agency_code,agency_name,officeid,officecode,officename,officetitle,officeabrv,oldofficeabrv,headofficer,headtitle,auth_head,auth_title,auth_description,signatory_status,office_gps_location,effectivity_date) VALUES 
				(:theagencycode,:theagencyname,'921011','1011','Governor','Office of the Provincial Governor','OPG','PGO','Ann K. Hofer','Governor','Atty. Christian Jay M. Millena','Provincial Administrator','By authority of the Governor','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'92101102','1011','Nutrition','Office of the Provincial Nutrition','OPN','-','Marelene  C. Garcia','Provincial Nutritionist','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'92101103','1011','Security','Office of the Provincial Security Guard','OPSG','PSG','Domingo D. Compra, Jr.','Acting Provincial Security Unit Head','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'92101104','1011','MSU','MSU Buug School of Nursing Ipil Extension','MSU','-','Cornelio Val J. Lotayco, RN, MAN.','Faculty/Coordinator<br>MSU Buug School of Nursing Ipil Extension','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'92101105','1011','SPTC','Sibugay Provincial Training Center','SPTC','-','Ann K. Hofer','Governor','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'92101106','1011','ICT','Office of the Provincial Information and Communication Technology','OPICT','-','Ann K. Hofer','Governor','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'921016','1016','Vice Governor','Office of the Provincial Vice Governor','OPVG','PVGO','Richard D. Olegario','Vice Governor','','','','1','7.787692943372631,122.57333016619424','45839'), 
				(:theagencycode,:theagencyname,'921021','1021','Sangguniang Panlalawigan','Office of the Provincial Sangguniang Panlalawigan','OPSP','SP','-','-','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'921022','1022','Secretary','Office of the Provincial Secretary','OPSec','-','-','Provincial Secretary','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'921031','1031','Administrator','Office of the Provincial Administrator','OPAd','-','Atty. Christian Jay M. Millena','Provincial Administrator','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'921032','1032','Human Resource Management','Office of the Provincial Human Resource Management','OPHRM','PHRMO','Nelsie P. Lazo','Provincial Human Resource Management Officer','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'921041','1041','Planning and Development','Office of the Provincial Planning and Development Coordinator','OPPDC','PPDO','Engr. Venancio A. Ferrer III','Provincial Planning and Development Officer','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'921061','1061','General Services','Office of the Provincial General Services','OPGS','PGSO','Sheldon A. Deypalubos','Provincial General Services Officer','','','','1','7.787913040938963,122.57452277897771','45839'), 
				(:theagencycode,:theagencyname,'921071','1071','Budget','Office of the Provincial Budget','OPB','PBO','Rosana T. Palalon','Provincial Budget Officer','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'92107101','1071','Procurement Services Depot','Office of the Provincial Procurement Service Depot','OPPSD','PS-DBM','Julito P. Ladeza','Depot Manager<br>PS-DBM Sibugay Depot','','','','1','7.787973414310944,122.57476609355287','45839'), 
				(:theagencycode,:theagencyname,'921081','1081','Accounting','Office of the Provincial Accountant','OPAcc','PAccO','Deo Marchu A. Daguio, CPA','Provincial Accountant','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'921091','1091','Treasurer','Office of the Provincial Treasurer','OPT','PTO','Clynia C. Page','Provincial Treasurer','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'921101','1101','Assessor','Office of the Provincial Assessor','OPAss','PAssO','Jocelyn D. Bracamonte, CPA','Provincial Assessor','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'921131','1131','Legal','Office of the Provincial Legal','OPL','PLO','Atty. Anna Liza L. Gonzales','Provincial Legal Officer','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'924411','4411','Health','Office of the Provincial Health','OPH','IPHO','Dr. Ulysses D. Silorio','OIC - Provincial Health Officer','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'927611','7611','Social Welfare and Development','Office of the Provincial Social Welfare and Development','OPSWD','PSWDO','Maricel C. Amorganda, RSW','Provincial Social Welfare and Development Officer','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'928711','8711','Agriculture','Office of the Provincial Agriculturist','OPAg','-','Engr. Wesley C. Sayson','Provincial Agriculturist','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'928721','8721','Veterenary','Office of the Provincial Veterenarian','OPVet','PVet','Efren M. Davin D.V.M.','Provincial Veterenarian','','','','1','7.787817133186198, 122.57570376729197','45839'), 
				(:theagencycode,:theagencyname,'928731','8731','Environment and Natural Resources','Office of the Provincial Environment and Natural Resource','OPENR','PENRO','Neneth T. Ordo~no','Provincial Environment and Natural Resource Officer','','','','1','7.7881218435487245,122.57361312438182','45870'), 
				(:theagencycode,:theagencyname,'928751','8751','Engineering','Office of the Provincial Engineer','OPE','PEO','Engr. Cristopher C. Lazo','Provincial Engineer','','','','1','7.787913040938963,122.57452277897771','45839'), 
				(:theagencycode,:theagencyname,'928761','8761','Cooperative','Office of the Provincial Cooperative','OPC','PCO','Atty. Socrates P. Villota, CPA','Acting Provincial Cooperative Officer','','','','1','7.787817133186198, 122.57570376729197','45839'), 
				(:theagencycode,:theagencyname,'929940','9940','Disaster Risk Reduction','Office of the Provincial Disaster Risk Reduction Management','OPDRRM','PDRRMO','Engr. Lloyd I. Pranza','Provincial Disaster Risk Reduction Management Officer','','','','1','7.787913040938963,122.57452277897771','45839'), 
				(:theagencycode,:theagencyname,'921061969','1061-969','Bids and Awards Committee','Office of the Provincial Bids and Awards Committee','OPBAC','BAC','Atty. Anna Liza L. Gonzales','BAC Chairperson','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'92111101','1111-01','Internal Audit Service','Office of the Provincial Internal Audit Service','OPIAS','IAS','Engr. Romel G. Duran','Acting Provincial Internal Auditor - FOCAL','','','','1','7.7881218435487245,122.57361312438182','45839'), 
				(:theagencycode,:theagencyname,'92441101','4411-01','Medical Center','Dr. George Tocao Hofer Medical Center','DGTHMC','ZSPH','Sherwin F. Bastero M.D., DPCP, FPSMS','Acting Chief of Hospital','','','','1','7.815454789510023,122.64179851717503','45839')
			";
			$stmtOfficeSignatoryTbl = $cnn->prepare($insertOfficeSignatoryTbl);
			$stmtOfficeSignatoryTbl->bindParam(':theagencycode', $the_agency_code);
			$stmtOfficeSignatoryTbl->bindParam(':theagencyname', $the_agency_name);
			$stmtOfficeSignatoryTbl->execute();

			echo "Default data added @ office_signatory_tbl successfully inserted. <br>";
		} else {
			echo "Already had office_tbl Default Data! <br>";
		}

		// Check if employee_type_tbl table exists
		$resultEmployeeTypeTbl = $cnn->prepare("SELECT * FROM employee_type_tbl");
		$resultEmployeeTypeTbl->execute();
		$countEmployeeTypeTbl = $resultEmployeeTypeTbl->rowCount();
		if ($countEmployeeTypeTbl > 0) {
				echo "Already had employee_type_tbl Default Data!. <br>";
		} else {
				// insert default data.
				$insertEmployeeTypeTbl = "INSERT INTO employee_type_tbl 
					(type_employee_abrv,type_employee) VALUES 
					(trim('REG'),trim('Regular/Permanent')),
					(trim('TMP'),trim('Temporary')), 
					(trim('COS'),trim('Contractual')), 
					(trim('JO'),trim('Casual')), 
					(trim('PRB'),trim('Probationary')), 
					(trim('COT'),trim('Coterminous'))
				";
				$stmtEmployeeTypeTbl = $cnn->prepare($insertEmployeeTypeTbl);
				$stmtEmployeeTypeTbl->execute();

				echo "Default data added @ employee_type_tbl successfully inserted. <br>";
		}

		// Check if bio_location_tbl table exists
		$resultBioLocationTbl = $cnn->prepare("SELECT * FROM bio_location_tbl");
		$resultBioLocationTbl->execute();
		$countBioLocationTbl = $resultBioLocationTbl->rowCount();
		if ($countBioLocationTbl > 0) {
				echo "Already had bio_location_tbl Default Data!. <br>";
		} else {
				// insert default data.
				$insertBioLocationTbl = "INSERT INTO bio_location_tbl 
					(agency_code,agency_name,bio_location,timelogs_type,xdel,createdby,modifiedby) VALUES 
					(:theagencycode,:theagencyname,trim('PGO'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('OPAd'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('OPAd2'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('Accounting'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('Agri'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('Budget'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('Coop'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('DRR'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('GSO'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('Health'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('HR'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('Legal'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('PAssO'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('PENRO'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('PEO1'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('PEO2'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('PPDO'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('PRECY'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('PSWD'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('PTO'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('PVet'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('IAS'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('MSU'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('Motorpool'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('PS-DBM'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('PEO-Diplahan'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('DGTHMC-REG'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('DGTHMC-COS'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('DGTHMC-JO'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('BAC'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('PEO-Motorpool'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('GSO-JO'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('SPTC'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('PVet-New'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('Nutrition'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('pswdo-new'),1,0,:createdby,:modifiedby), 
					(:theagencycode,:theagencyname,trim('SUCLEMA'),1,0,:createdby,:modifiedby)
				";
				$stmtBioLocationTbl = $cnn->prepare($insertBioLocationTbl);
				$stmtBioLocationTbl->bindParam(':theagencycode', $the_agency_code);
				$stmtBioLocationTbl->bindParam(':theagencyname', $the_agency_name);
				$stmtBioLocationTbl->bindParam(':createdby', $createdby);
				$stmtBioLocationTbl->bindParam(':modifiedby', $modifiedby);
				$stmtBioLocationTbl->execute();

				echo "Default data added @ bio_location_tbl successfully inserted. <br>";
		}
	} catch(PDOException $e) {
		echo "System Error ".$e->getMessage()." <br>";
	}