
    <style type="text/css">
		body {
			font-family: Tahoma, Geneva, sans-serif;
		}

		section {
			text-align: center;
			width: 100%;
			max-width: 453px;
			margin: 0 auto;
			margin-top: 4rem;
		}

		h1 {
			font-size: 8rem;
			margin: 0;
		}

		a {
			text-decoration: none;
		}

		span {
			font-size: 80px;
		}
	</style>
	
	<section id="signup" class="w-100 mh-100 pt-3" style="padding-bottom: 62px;">
		<div class="container mh-100">
			<div class="card m-auto" style="max-width: 1024px;">
				<div class="card-header"><h5 class="text-center text-primary">Sign-Up Account</h5></div>

				<div class="card-body">
					<p>Maintenance</p>
            		<span>&#9995;</span>
            		<H1>503</H1>
            		<p>We're very sorry for the inconvenience but we're performing maintenance.</p>
            		<a href="/">Home</a> | 
            		<a href="tel:+639154826025" title="Ludwig Bethnicer C. Napigkit" target="_blank">Contact Us</a> | 
            		<a href="mailto:alphaphpn@gmail.com" title="AlphaPHPn I.T. Services" target="_blank">E-mail</a> | 
            		<a href="//facebook.com/alphaphpn" title="AlphaPHPn Facebook" target="_blank">facebook</a> | 
            		<a href="javascript: location.reload()">Reload</a>
				</div>
			</div>
		</div>
	</section>