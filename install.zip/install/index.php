<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="refresh" content="300;">
	<title>Install First TIme</title>
	<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
	<META HTTP-EQUIV="Expires" CONTENT="-1">
	<style type="text/css">
		body {
			font-family: Tahoma, Geneva, sans-serif;
		}

		section {
			text-align: center;
			width: 100%;
			max-width: 453px;
			margin: 0 auto;
			margin-top: 4rem;
		}

		h1 {
			font-size: 3rem;
			margin: 0;
		}

		a {
			text-decoration: none;
		}

		span {
			font-size: 80px;
		}
	</style>
</head>
<body oncontextmenu="return false;">
	<section>

		<?php 

			try {

				require_once "../lib/env.php";

				$cnn = null;

				$cnn = new PDO("mysql:host={$host};dbname={$db}", $uname, $pw);
				$cnn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

				// Check if user_tbl table exists
				$resultUserTbl1 = $cnn->prepare("SELECT * FROM user_tbl");
				$resultUserTbl1->execute();
				$countUserTbl1 = $resultUserTbl1->rowCount();
				if ($countUserTbl1 > 0) {
					echo '<script>window.open("../attendance-auth","_self");</script>';
				} else {
		?>
		
		<?php	
				}
			} catch ( PDOException $e ) {
		?>
		
			<span>&#128064;</span>
			<h1>Install for the First Time</h1>
			<p>This page allows you to install the system for the first time.</p>
			<a href="/beetpress/">Home</a> | 
			<a href="/beetpress/dbase">Install</a> | 
			<a href="javascript: history.back()">Back</a> | 
			<a href="javascript: location.reload()">Reload</a> | 
			<a href="/beetpress/">Done</a>

		<?php
			}
			
		?>
		
	</section>
</body>
</html>